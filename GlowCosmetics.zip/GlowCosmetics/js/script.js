let cart_icon = document.querySelector('.cart_icon');
let close = document.querySelector('.close');
let body = document.querySelector('body');

cart_icon.addEventListener('click', ()=>{
    body.classList.toggle('cart-toggle')
})

close.addEventListener('click',() =>{
    body.classList.toggle('cart-toggle')

})
